# To add a new cell, type '# %%'
# To add a new markdown cell, type '# %% [markdown]'
# %%
from descartes import PolygonPatch
import json
import matplotlib
from matplotlib.animation import FuncAnimation
# http://scip-interfaces.github.io/PySCIPOpt/docs/html/
from pyscipopt import Model, quicksum
from shapely.geometry import Point
import environment

# SCIP model
model = Model("motion-planning")

# %% [markdown]
# # Task 4: Motion Planning
#
# _The story so far..._
#
# The year is 2032 and you are a mission specialist NASA astronaut on the surface of the Moon. Alongside the Artemis IV habitat, you and your crewmates have set up an array of geology stations around the habitat. These stations need servicing and sample collection every once in a while, a job that you've delegated to robots. It's your job to make sure that your autonomous robot mechanics can find their way to the stations while avoiding obstacles on the surface.
#
# The rovers themselves have speed limits.
#
#
# ## The Environment
#
# Run the cell below to see the environment.

# %%
env = environment.Environment(yaml_file="env.yaml")
fig, axes = environment.plot_environment(env)

# %% [markdown]
# This next cell demonstrates creating an animation with matplotlib. If you run it, it creates a gif that shows a loop of a point moving through the environment. It doesn't animate properly in the notebook, but it should animate fine by itself in a browser window.
#
# I think you need `imagemagick` installed for this to run correctly.

# %%
starting_point = (-4, -4)
radius = 0.3

fig, axes = environment.plot_environment(env)

last_patch = []

def init():
    rover = Point(starting_point[0], starting_point[1]).buffer(radius, resolution=3)
    patch = PolygonPatch(rover, fc="green", ec="black", alpha=1.0, zorder=1)
    axes.add_patch(patch)
    last_patch.append(patch)
    return patch,

def animate(i):
    last_patch.pop().remove()

    rover = Point(starting_point[0] + (i % 20) / 10., starting_point[1] + (i % 20) / 10.).buffer(radius, resolution=3)
    patch = PolygonPatch(rover, fc="green", ec="black", alpha=1.0, zorder=1)
    axes.add_patch(patch)

    last_patch.append(patch)
    return patch,

anim = FuncAnimation(fig, animate, init_func=init, frames=200, interval=20, blit=True)
anim.save('testing.gif', writer='imagemagick')


# %%
with open('notamoon.json') as f:
    ex_json_dict = json.load(f)
plt = matplotlib.pyplot
plt.figure()

for obs in ex_json_dict['obstacles']:
    coord = np.array(obs['geometry']['coordinates'])
    plt.plot(coord[:,0],coord[:,1],'-r')
plt.gca().set_aspect('equal','box')
plt.draw()
line1,= plt.plot(coord[:,0],coord[:,1],'-r',label='Obstacles')

coord = np.array(ex_json_dict['goal']['geometry']['coordinates'])
line2,=plt.plot(coord[:,0],coord[:,1],'k-',label='Goal Region')

line3,=plt.plot(0,0,'*b',label='Start Location')
plt.legend(handles=[line1,line2,line3],loc='best')

# %% [markdown]
# ## What is trajectory optimization?
#
# The goal of trajectory optimization is to minimize a performance measure while satisfying constraints. In this case, we will be minimizing the total distance the robot travels to complete the mission while avoiding obstacles and respecting a speed limit.
#
# There are three constraints in the basic encoding of the problem:
# 1. Avoid all obstacles
# 2. Maintain a speed under the speed limit
# 3. Minimize the distance traveled between the start point and the end point
#
#
# %% [markdown]
# ## Avoiding Obstacles
#
# We can assume all obstacles are quadrilaterals-- that they have four sides. The easiest obstacles to constrain are rectangles, but non-parallelograms can be approximated as rectangles by extending the sides until a rectangle is formed. Each side of the rectangle can be modeled as four intersecting lines. By defining these lines as inequalities, we can establish obstacles as no-go areas for the robot.
# The obstacles are defined by the line equations that make up their sides.
# These inequalities become our constraints for avoiding obstacles.
#
# $\forall t \in [1 ..., T]:~x_t \leq x_{min}$ <br>
# $or~x_i \geq x_{max}$ <br>
# $or~y_i \leq y_{min}$ <br>
# $or~y_i \geq y_{max}$ <br>
#
# These constraints are 'or' statements, but 'and' statements are more useful for our purposes. We can transform the constraints from 'or' to 'and' by introducing binary variables ($t_i$) and $M$ (an arbitrarily large number).
#
# ### Binary Slack Variables
#
#
# These constraints are also now mixed-integer/linear constraints, which are more useful in solving the optimization problem:<br>
# $\forall i \in [1 ..., N]:~x
#
# This process is repeated for each obstacle in the environment. Thus, the amount of binary slack variables given to the solver is 4 times the number of obstacles._i \leq x_{min}~+~Mt_{i1}$ <br>
# $and~x_i \leq -x_{max}~+~Mt_{i2}$ <br>
# $and~y_i \leq y_{min}~+~Mt_{i3}$ <br>

# %% [python]
# ## Obstacle avoidance code
#
# $and~-y_i \leq -y_{max}~+~Mt_{i4}$ <br>
#
# Below, we'll implement obstacle constraints using pySCIOPT.

# %% [python]
"""
add all variables for obstacle avoidance
"""

# slopes(?)

# TODO: use the obstacles themselves to get A, b
A1 = model.addVar("A1", vtype="CONTINUOUS")
A2 = model.addVar("A2", vtype="CONTINUOUS")
A3 = model.addVar("A3", vtype="CONTINUOUS")
A4 = model.addVar("A4", vtype="CONTINUOUS")

# y-intercepts(?)
b1 = model.addVar("b1", vtype="CONTINUOUS")
b2 = model.addVar("b2", vtype="CONTINUOUS")
b3 = model.addVar("b3", vtype="CONTINUOUS")
b4 = model.addVar("b4", vtype="CONTINUOUS")

# binary slack variables, either 0 or 1
# lb == lower bound, ub == upper bound
y1 = model.addVar("y1", vtype="INTEGER", lb=0, ub=1)
y2 = model.addVar("y2", vtype="INTEGER", lb=0, ub=1)
y3 = model.addVar("y3", vtype="INTEGER", lb=0, ub=1)
y4 = model.addVar("y4", vtype="INTEGER", lb=0, ub=1)

# an arbitrarily large barrier variable
M = model.addVar("M", vtype="INTEGER")

# the position in the environment
x1 = model.addVar("x1", vtype="CONTINUOUS")
x2 = model.addVar("x2", vtype="CONTINUOUS")

# avoid all the obstacles using binary slack variables
model.addCons(A1 * x1 - b1 <= (1 - y1) * M)
model.addCons(A2 * x2 - b2 <= (1 - y2) * M)
model.addCons(A3 * x3 - b3 <= (1 - y3) * M)
model.addCons(A4 * x4 - b4 <= (1 - y4) * M)

# ensure that at least one y is 1
model.addCons(quicksum([y1, y2, y3, y4]) >= 1)

model.optimize()
sol = model.getBestSol()
print(sol)

# %% [markdown]
# ## Obeying the Speed Limit
#
# In the problem given, we're told that the agent has a speed limit - in other words the robot has a limit on how much it can change its position, $d$, during a single time step. We are also ignoring vehicle dynamics when considering position changes. Thus position changes are allowed so long as the magnitude of the change in position is within $d \leq v_max*t$.
#
# A speed limit is defined as a quadratic constraint. Consider the diagram below.
#
# <img src="speed-limit-quadratic-constraint.svg" alt="Drawing" style="width: 200px;"/>

# The circle shows the maximum distance the robot can travel within a time step. This limits the speed the robot can reach to the radius of the cirlce.
# The maximum velocity is $v_{max} = \sqrt{v_x^2 + v_y^2}$.
#
# To determine the distance traveled, just use physics: $x' = x + \vec{x} \delta t$.

# %% [python]
model.addVar()

#
#
#
#
# %% [markdown]
# ## Minimizing Distance
#
# The solver will determine the most optimal path for the robot to take to minimize distance travelled while still meeting the constraints.
#
# Your objective function is $\min \sum_{d_{sq}}$
#
# %% [markdown]
# ## Encoding the problem with Mixed Integer Quadratic Constrained Programs (MIQCP)
# A mixed integer quadratic constrained program (MIQCP) is a method of generating an optimal vehicle trajectory while abiding by both integer and quadratic constraints [Schouwenaars et al.]. The program seeks to minimize a cost function $J$ over the trajectory to provide the desired performance in terms of time or fuel expenditure. Trajectories over discrete time steps ($t_0, t_1, ..., t_N$) consist of a sequence of states $s$ and control inputs $u$. The cost function is generally represented as a quadratic function in order to render it easily solvable through convex optimization methods. Constraints are also often added to the problem, representing state dynamics and state variable/control input limits. These constraints can be linear or quadratic, as in the case of speed limits.
#
# Why are speed limits quadratic constraints? Consider the diagram below.
#
# <img src="speed-limit-quadratic-constraint.svg" alt="Drawing" style="width: 200px;"/>
#
# Given a speed limit, the maximum velocity is represented by the circle. The maximum velocity is $v_{max} = \sqrt{v_x^2 + v_y^2}$.
#
# However, the presence of obstacles leads to unique integer constraints. For example, for a rectangular obstacle, the constraints are represented as a set of four $or$ constraints: <br>
# $\forall i \in [1 ..., N]:~x_i \leq x_{min}$ <br>
# $or~x_i \geq x_{max}$ <br>
# $or~y_i \leq y_{min}$ <br>
# $or~y_i \geq y_{max}$ <br>
# Non-rectangular obstacles can be formulated by rectangles by using the minimum/maximum vertices in each direction.
#
# But by introducing binary variables ($t_i$) and $M$ (an arbitrarily large number), the constraints can be changed to $and$ statements. These constraints are also now mixed-integer/linear constraints, which are more useful in solving the optimization problem:<br>
# $\forall i \in [1 ..., N]:~x_i \leq x_{min}~+~Mt_{i1}$ <br>
# $and~x_i \leq -x_{max}~+~Mt_{i2}$ <br>
# $and~y_i \leq y_{min}~+~Mt_{i3}$ <br>
# $and~-y_i \leq -y_{max}~+~Mt_{i4}$ <br>
#
# Putting together the quadratic cost function and full set of constraints (including the mixed-integer /linear obstacle constraints), we have a mixed-integer quadratically constrained program, which is solvable by various methods. The variables $\mathbf{q}$, $\mathbf{r}$, $\mathbf{p}$ represent cost weights on the state error, control cost, and terminal state error, respectively.<br>
#
# $J = \sum_{i=1}^{N}\mathbf{q}|s_i - s_f| + \sum_{i=1}^{N}\mathbf{r}|u_i|+\mathbf{p}|s_N-s_f|$<br><br>
# $\forall i \in [1 ..., N]:~x_i \leq x_{min}$ <br>
# $or~x_i \geq x_{max}$ <br>
# $or~y_i \leq y_{min}$ <br>
# $or~y_i \geq y_{max}$ <br><br>
# $\forall i \in [1 ..., N]:~x_i \leq x_{min}~+~Mt_{i1}$ <br>
# $and~x_i \leq -x_{max}~+~Mt_{i2}$ <br>
# $and~y_i \leq y_{min}~+~Mt_{i3}$ <br>
# $and~-y_i \leq -y_{max}~+~Mt_{i4}$ <br>
#
#
# <br>
# PROBLEM DEFINITION:
# State variables (s):<br>
# $x$<br>$y$<br>$xdot$<br>$ydot$<br>
#
# Control variables (u):<br>
# $a_x$<br>$a_y$<br>
#
# Given:<br>
# $x0$<br>$y0$<br>$xf~(goal)$<br>$yf~(goal)$<br>
# vertices of all obstacles ($x_{o1}min, y_{o1}min, x_{o1}max, y_{o1}max$) (obs. 1), ($x_{o2}min, y_{o2}min, x_{o2}max, y_{o2}max$) (obs. 2), ...<br>
# vertices of factory limits ($x_{min}, y_{min}, x_{max}, y_{max}$)<br>
# speed limit $v_{max}$<br>
# time step $dt$<br><br>
#
# <br>
# POTENTIAL PROBLEMS (answers should be in code to be able to subsequently solve the optimization problem)<br>
# Problem 1. Given the problem above, define the quadratic cost function.<br>
# Answer: Equation 8 in [Schouwenaars et al.] paper (doesn't have to be that rigorous, but should include the state error term, control term, terminal cost term, and the q/r/p weights for each term).<br><br>
#
# Problem 1a. Implement the cost function in python.
#
# Problem 2. Define state equations and the A and B matrices so that:<br>
# $\dot s = As + Bu$ (or give them the A and B matrices explicitly)?<br>
# Answer: TBD<br><br>
#
# Problem 3. Define constraints for problem.<br>
# Answer: TBD
# %% [markdown]
# ## Methods for Solving Convex Optimization
#
# Optimization: Find the best possible solution by comparing solutions unil the optimal one is found.
#
# Convex Optimization: Optimizing a convex function over a convex set by finding the global minimum.
#
# Convex Function: Think happy face!
# Example of a convex function: insert photo
#
# Convex Set: a 2D set where two points must be connected by a line that must be within the set.
#
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
# We use the barrier method to solve this convex optimization problem by using barrier values (very large values) to deter the robot from accessing the obstacle regions.
#
# Other methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
#
# Ellipsoid method: using smaller and smaller ellipsoids to limit the solution space within the convex set.
#
# Subgradient method: used when the convex fucntion is non-differentiable.
#
# Cutting plane: used to solve mixed integer linear programming by "cutting" off sections of the solution set to find the integer solution.
#
# %% [markdown]
# ## Solve the MIQCP with Python
#
# Have students implement the function below:
#
# ```python
# def miqcp(environment, starting_points, end_points):
#     raise NotImplemented()
# ```
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
# For a convex problem, taking small steps in the direction of greatest descent will eventually find the global minimum and any local minimum found is also a global minimum.
#
#
# Example methods for solving convex optimization:
#
# Ellipsoid method: using smaller and smaller ellipsoids to limit the solution space within the convex set.
#
# Subgradient method: used when the convex fucntion is non-differentiable.
#
# Cutting plane: used to solve mixed integer linear programming by "cutting" off sections of the solution set to find the integer solution.
#
# %% [markdown]
# ## Solve the MIQCP with Python
#
# Have students implement the function below:
#
# ```python
# def miqcp(environment, starting_points, end_points):
#     raise NotImplemented()
# ```
# %% [markdown]
# ## Solve the MIQCP with ScottyConvexPath
#
# Ask TAs: do we have students use ScottyConvexPath offline? do we run ScottyConvexPath and show the results in the notebook?
#
# Ask Simon
# %% [markdown]
# ## Advanced Modeling
#
# Bonus points: add more constraints?
#   * stop at locations along the path to perform other objectives?
#   * minimize fuel?
#   * more realistic rover dynamics?
#       * $v_{x2} - v_{x1} < \alpha$ or something like that
#   * more realistic terrain?
#     * lunar digital elevation model

# %%



