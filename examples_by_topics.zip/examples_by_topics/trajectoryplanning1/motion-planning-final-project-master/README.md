# Motion Planning Final Project

## Installation

### Requirements

1. Python 3.6+
2. PySCIPOpt, one of our dependencies, requires [SCIP](https://scip.zib.de/) headers, which need to be installed separately.
  1. General instructions on installing [PySCIPOpt](https://github.com/SCIP-Interfaces/PySCIPOpt/blob/master/INSTALL.md)
  2. Download [scipoptsuite](https://scip.zib.de/index.php#download). We'd recommend using an installer if one is available for your OS. If not, you can [install it from source with cmake](https://scip.zib.de/doc/html/CMAKE.php)
    * (For those of us like Cameron who use Arch linux, here's the [AUR](https://aur.archlinux.org/packages/scipoptsuite/))

Steps:
1. `cd` to downloaded github directory
2. `git pull origin master` (get latest version of repository)
3. `. .venv/bin/activate` (activates the virtual environment we created)
4. `pip install -r requirements.txt` (install dependencies)
5. `jupyter notebook` (open up jupyter notebook)
6. `deactivate` (exit virtual environment)

Pushing files that were changed:
1. `git add . README.md` (or whatever file you changed was)
2. `git commit` (adds commit message, detail the changes)
3. `git push` (uploads the updated files)


## Notes from Post-Skeleton Meeting with Simon

constraints are:
1. avoid obstacles
2. speed limit
  * `<=` needs to be a big part of explanation
3. minimize distance
  * for t \in T, where T is fixed. hence this handles a distance)
  * we can change timesteps

* Do a basic encoding. Then talk about advanced encoding.
* Generate the obstacles using lines to more easily get the linear inequalities for the obstacles
  * enforce that the linear inequalities are true for every x at every timestep
  * can get computationally expensive - maybe use fewer variables at first

for obstacle avoidance:
using binary constraints to get rid of ORs
dump constraints into a MILP, which does a search for y_i

minimize total distance

for second (advanced) part

scotty is a continuous time formulation
* in encoding - time and position are decision variables
* tricky part is avoiding obstacles
* uses intersections of free spaces to pick points
* also works with nonlinear dynamics

for convex:
* don't need to go into detail about all the methods
  * barrier methods should have details. but the rest exist
  * scotty is an example

for the solver:
* SCIP is what we'll use. pySCIPOPT is in pip
* can't handle quadratic const functions

for the first notebook and the simple constraints:
* 5 obstacles, 10 time steps
* if it takes too long, reduce # of time steps and obstacles


for advanced:
* take a stab at implementing scotty
* what if there are multiple agents?
  * treat each agent as an obstacle. commit to a path, then use each position as an additional constraint
